Project 1 - Movies Website

What is it?
-------------
A simple server-side Python program which conatins information and media about various movies and displays them on a dynamically generated web page.

Included Files
-------------
media.py - Contains the class definition for the Movie class
entertainment_center.py - Contains the code that creates the movie objects to be sent to the website
fresh_tomatoes.py - Contains the code that generates the website for the user

To Run
-------------
Open the entertainment_center.py module and run it.